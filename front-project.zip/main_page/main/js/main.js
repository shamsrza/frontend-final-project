//carousel-1
$(document).ready(function(){
  $(".owl-one").owlCarousel({
    margin: 30,
    loop: true,
    responsive: {
      0: {
        items: 1,
      },
      992: {
        items: 2,
      },
    },
  });
  $(".my-next-button").click(function () {
    $(".owl-one").trigger("next.owl.carousel");
  });

  $(".my-previous-button").click(function () {
    $(".owl-one").trigger("prev.owl.carousel");
  });


//carousel-2

  $(".owl-two").owlCarousel({
    loop: false,
    margin: 35,
    nav: false,
    responsive:{
      0:{
          items:1
      },
      600:{
          items:3
      },
      1500:{
          items:4,
      }
  }
  });

  $(".my-next-button").click(function () {
    $(".owl-two").trigger("prev.owl.carousel");
    $(".my-next-button").css("color", "grey");
    $(".my-previous-button").css("color", "black");
  });

  $(".my-previous-button").click(function () {
    $(".owl-two").trigger("next.owl.carousel");
    $(".my-previous-button").css("color", "grey");
    $(".my-next-button").css("color", "black");
  });


  for(let i =0 ;i < 6; i++){
    $(`#fav-${i}`).mouseover(function(){
      $(`.fav-comment-${i}`).css("visibility", "visible");
    });
    $(`#fav-${i}`).mouseout(function(){
      $(`.fav-comment-${i}`).css("visibility", "hidden");
    });

  }
  
  for(let i =0 ;i < 6; i++){
    $(`#rev-${i}`).mouseover(function(){
      $(`.rev-comment-${i}`).css("visibility", "visible");
    });
    $(`#rev-${i}`).mouseout(function(){
      $(`.rev-comment-${i}`).css("visibility", "hidden");
    });
  }

  for(let i = 0; i < 6; i++){
    $(`.owl-item-${i}`).mouseover(function(){
      $(`#rev-${i}`).css("visibility", "visible");
      $(`.stars-${i}`).css("visibility", "visible");
      $(`.card_btn-${i}`).css("visibility", "visible").stop(true, false).animate({top: '278px'}, "2");   
      if ($(window).width() < 1570) {      
          $(`.card_btn-${i}`).css("visibility", "visible").stop(true, false).animate({top: '250px'}, "2");
        }  
    });

      $(`.owl-item-${i}`).mouseout(function(){
      $(`#rev-${i}`).css("visibility", "hidden");
      $(`.stars-${i}`).css({"visibility": "hidden", "position" : "relative"});
      $(`.card_btn-${i}`).stop(true, false).animate({top: '300px'}, "2", function() {
        $(this).next().show();
        $(this).css("visibility", "hidden");
    });

    if ($(window).width() < 1570) {      
      $(`.card_btn-${i}`).stop(true, false).animate({top: '278px'}, "2", function() {
        $(this).next().show();
        $(this).css("visibility", "hidden");
    });
    }  
  });

  }

  for(let i = 1; i < 6; i++){
    $(`.owl-item-${i}`).mouseover(function(){
      $(`.product-card_img-${i}`).attr('src',function(index, attr){
      return attr.replace(`card-tea-${i+(i-1)}.jpg`,`card-tea-${i*2}.jpg`);});   
    });
    $(`.owl-item-${i}`).mouseout(function(){
      $(`.product-card_img-${i}`).attr('src',function(index, attr){
      return attr.replace(`card-tea-${i*2}.jpg`,`card-tea-${i+(i-1)}.jpg`);});
      });
  }

  $("[data-fancybox]").fancybox({
    youtube: {
      controls: 0,
      showinfo: 0,
    },
    vimeo: {
      color: "f00",
    },
  });

  $(".fancybox").fancybox({ width: 1000, height: 550, autoSize: false });


// footer carousel
  $('.owl-three').owlCarousel({
      loop:true,
      responsiveClass:true,
      dotsEach: true,
      responsive:{
          0:{
              items:1,
              nav:false,
              loop: false
          },
          600:{
              items:2,
              nav:false,
              loop: false
          },
          768:{
              items:3,
              nav:false,
              loop: false
          },
          1100:{
              items:4,
              nav:false,
              loop:false,
              margin: 30
          }
      }
  })

  $(".gallery-2").fancybox({
    transitionIn: "elastic",
    transitionEffect: "fade",
    transitionOut: "elastic",
    speedIn: 600,
    speedOut: 200,
    overlayShow: true,
    opacity: true,
    cyclic: true,
  });

  $.fancybox.defaults.buttons = ["zoom", "slideShow", "close"];

});
